//console.log can print something on console 
console.log(`hello white`);
