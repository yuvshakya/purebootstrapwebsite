
"use strict";

//intro to variables 
// cariables can store some infromation 
// we can use that information later 
// we can change that information later


// declare a variable
var firstName = "Harshit";

// use a variable
console.log(firstName);

// change value
//firstname = "Mohit"; this is different  which is call case sensitive firstName and firstname
firstName = "Mohit";
console.log(firstName);//these are both different way the var firstName = "Harshit" and only firstName = "Mohit";
